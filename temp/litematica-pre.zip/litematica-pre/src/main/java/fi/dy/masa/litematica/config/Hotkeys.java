package fi.dy.masa.litematica.config;

import java.util.List;
import com.google.common.collect.ImmutableList;
import fi.dy.masa.malilib.config.options.ConfigHotkey;
import fi.dy.masa.malilib.hotkeys.KeybindSettings;

public class Hotkeys
{
    public static final ConfigHotkey ADD_SELECTION_BOX                  = new ConfigHotkey("新增选择框",                   "M,A",  "在此位置新增一个名为“位置1”的选择框。");
    public static final ConfigHotkey CLONE_SELECTION                    = new ConfigHotkey("克隆选区",                    "",     "快速克隆当前选择区域，\n这只是创建一个存在游戏内剪切板里的原理图，\n然后在另外一个位置上再次选择该原理图，\n同时手持本模组的工具然后将模式切换到‘将原理图粘贴到世界上’模式。");
    public static final ConfigHotkey DELETE_SELECTION_BOX               = new ConfigHotkey("删除选择框",                "",     "删除当前已选择的选区。");
    public static final ConfigHotkey EASY_PLACE_ACTIVATION              = new ConfigHotkey("放置方块 - 简单模式",                   "BUTTON_2", KeybindSettings.PRESS_ALLOWEXTRA, "当开启‘简单模式’后，\n该按键可用于放置方块。");
    public static final ConfigHotkey EASY_PLACE_TOGGLE                  = new ConfigHotkey("切换简单模式",                   "",     "打开或者关闭‘简单模式’的快捷键。");
    public static final ConfigHotkey EXECUTE_OPERATION                  = new ConfigHotkey("执行操作",                  "",     "在“填充”、“替换”、“粘贴”原理图等模式下，\n使用当前选择的工具执行当前的选择或者放置操作。");//Joke
    public static final ConfigHotkey INVERT_GHOST_BLOCK_RENDER_STATE    = new ConfigHotkey("切换幽灵方块的渲染状态",       "",     "按住此按键时将会切换原理图/幽灵方块的渲染状态。");
    public static final ConfigHotkey INVERT_OVERLAY_RENDER_STATE        = new ConfigHotkey("切换叠加渲染状态",          "",     "按住此键时将调用叠加渲染状态。");
    public static final ConfigHotkey LAYER_MODE_NEXT                    = new ConfigHotkey("下一页",                     "M,PAGE_UP",    "将所有图层向前延伸渲染模式");
    public static final ConfigHotkey LAYER_MODE_PREVIOUS                = new ConfigHotkey("上一页",                 "M,PAGE_DOWN",  "将所有图层向后延伸渲染模式");
    public static final ConfigHotkey LAYER_NEXT                         = new ConfigHotkey("向上移动",                         "PAGE_UP",      "将已渲染的图层向上移动。");
    public static final ConfigHotkey LAYER_PREVIOUS                     = new ConfigHotkey("向下移动",                     "PAGE_DOWN",    "将已渲染的图层向下移动。");
    public static final ConfigHotkey LAYER_SET_HERE                     = new ConfigHotkey("设置当前位置",                      "",     "将渲染层设置为当前玩家所在位置。");
    public static final ConfigHotkey NUDGE_SELECTION_NEGATIVE           = new ConfigHotkey("向负方向移动",            "",     "向负方向移动当前选区，\n这基本与手持本模组工具然后按下‘切换键’（默认Ctrl键） + ‘鼠标滚轮’的功能一致。");
    public static final ConfigHotkey NUDGE_SELECTION_POSITIVE           = new ConfigHotkey("向正方向移动",            "",     "向正方向移动当前选区，\n这基本与手持本模组工具然后按下‘切换键’（默认Ctrl键） + ‘鼠标滚轮’的功能一致。");
    public static final ConfigHotkey MOVE_ENTIRE_SELECTION              = new ConfigHotkey("移动整个选区",               "",     "将整个选区移动到目前所玩家所在位置。");
    public static final ConfigHotkey OPEN_GUI_AREA_SETTINGS             = new ConfigHotkey("打开选区编辑",               "KP_MULTIPLY", "打开当前选区的编辑界面。");
    public static final ConfigHotkey OPEN_GUI_LOADED_SCHEMATICS         = new ConfigHotkey("打开已加载原理图",           "",     "打开已加载原理图界面。");
    public static final ConfigHotkey OPEN_GUI_MAIN_MENU                 = new ConfigHotkey("打开主菜单",                   "M",    KeybindSettings.RELEASE_EXCLUSIVE, "打开本模组的主菜单。");
    public static final ConfigHotkey OPEN_GUI_MATERIAL_LIST             = new ConfigHotkey("打开当前原理图的材料清单",               "M,L",  "打开当前已选原理图的材料清单界面。");
    public static final ConfigHotkey OPEN_GUI_PLACEMENT_SETTINGS        = new ConfigHotkey("打开原理图放置界面",          "KP_SUBTRACT", "打开当前已选原理图的放置或子区域的放置界面。");
    public static final ConfigHotkey OPEN_GUI_SCHEMATIC_PLACEMENTS      = new ConfigHotkey("打开原理图管理界面",        "M,P",  "打开原理图管理放置界面。");
    public static final ConfigHotkey OPEN_GUI_SCHEMATIC_PROJECTS        = new ConfigHotkey("原理图VCS版本管理界面",          "",     "打开原理图VCS界面");
    public static final ConfigHotkey OPEN_GUI_SCHEMATIC_VERIFIER        = new ConfigHotkey("打开原理图验证界面",          "M,V",  "打开当前已选择的原理图验证程序界面。");
    public static final ConfigHotkey OPEN_GUI_SELECTION_MANAGER         = new ConfigHotkey("打开选区目录界面",           "M,S",  "打开选区目录界面。");
    public static final ConfigHotkey OPEN_GUI_SETTINGS                  = new ConfigHotkey("打开设置界面",                   "M,C",  "打开设置界面。");
    public static final ConfigHotkey OPERATION_MODE_CHANGE_MODIFIER     = new ConfigHotkey("切换工具模式",       "LEFT_CONTROL", KeybindSettings.MODIFIER_INGAME, "切换键可快速修改当前模组工具上的模式，\n手持模组工具然后按下‘切换键’（默认Ctrl键） + ‘鼠标滚轮’即可切换模式。");
    public static final ConfigHotkey PICK_BLOCK_FIRST                   = new ConfigHotkey("一键选取首个方块",                    "BUTTON_3",     KeybindSettings.PRESS_ALLOWEXTRA, "一键选取接触到原理图的第一个方块，\n这和创造模式的中键的选取功能一样。");
    public static final ConfigHotkey PICK_BLOCK_LAST                    = new ConfigHotkey("一键选取最后方块",                     "",             KeybindSettings.MODIFIER_INGAME, "选取位于原理图预览后面的方块，\n这对于纠正原理图最后位置上的方块非常有用，\n这允许你将现有的方块放置到原理图中。");
    public static final ConfigHotkey PICK_BLOCK_TOGGLE                  = new ConfigHotkey("切换‘选取方块’",                   "M,BUTTON_3",   "一个用于快速切换“‘通用’->‘选取方块’”的快捷键，\n如果被它们打扰到了什么这个快捷键就可以快速开启或者关闭。");
    public static final ConfigHotkey RENDER_INFO_OVERLAY                = new ConfigHotkey("方块渲染信息",                 "I",            KeybindSettings.PRESS_ALLOWEXTRA, "启用方块渲染信息的快捷键，\n在‘外观’中的对应选项中可禁用，快捷键设置为‘NONE’也可禁用。");
    public static final ConfigHotkey RENDER_OVERLAY_THROUGH_BLOCKS      = new ConfigHotkey("叠加层透过方块渲染",        "RIGHT_CONTROL", KeybindSettings.PRESS_ALLOWEXTRA, "一个允许叠加层通过方块进行渲染，\n这只是一个更快捷的方式，功能与“‘外观’ -> ‘原理图叠加时透视方块’”基本一致。");
    public static final ConfigHotkey RERENDER_SCHEMATIC                 = new ConfigHotkey("刷新原理图渲染",                 "F3,M", "用于刷新或者重绘原理图的快捷键，\n而不是使用原版的’F3+A‘去刷新地形。");
    public static final ConfigHotkey SAVE_AREA_AS_IN_MEMORY_SCHEMATIC   = new ConfigHotkey("将选区保存到原理图",       "",     "将当前选择的区域保存到游戏内的剪切板中。");
    public static final ConfigHotkey SAVE_AREA_AS_SCHEMATIC_TO_FILE     = new ConfigHotkey("将选区另存为文件",         "LEFT_CONTROL,LEFT_ALT,S",  "将当前选择的区域另存为本地文件。");
    public static final ConfigHotkey SCHEMATIC_EDIT_BREAK_ALL_EXCEPT    = new ConfigHotkey("破坏所有非原理图方块",       "", KeybindSettings.MODIFIER_INGAME, "该快捷键可通过手持模组工具切换到“编辑原理图”模式下并按下该快捷键激活，\n当你破坏非原理图的材料列表中的方块时，\n除此之外所有的非原理图方块都会被清除。");
    public static final ConfigHotkey SCHEMATIC_EDIT_BREAK_ALL           = new ConfigHotkey("放置所有原理图方块",        "", KeybindSettings.MODIFIER_INGAME, "该快捷键可通过手持模组工具切换到“编辑原理图”模式下激活定向或连续破坏或者放置方块的功能。");
    public static final ConfigHotkey SCHEMATIC_EDIT_BREAK_DIRECTION     = new ConfigHotkey("连续方块方向",  "", KeybindSettings.MODIFIER_INGAME, "该快捷键可通过手持模组工具切换到“编辑原理图”模式下控制连续破坏或者放置功能的方向。");
    public static final ConfigHotkey SCHEMATIC_EDIT_REPLACE_ALL         = new ConfigHotkey("替换全部方块",           "", KeybindSettings.MODIFIER_INGAME, "该快捷键可通过手持模组工具切换到“替换”模式下激活替换所有相同方块的功能。");
    public static final ConfigHotkey SCHEMATIC_EDIT_REPLACE_BLOCK       = new ConfigHotkey("替换方块类型",         "", KeybindSettings.MODIFIER_INGAME, "该快捷键可通过手持模组工具切换到“替换”模式下激活替换方块类型的功能。");
    public static final ConfigHotkey SCHEMATIC_EDIT_REPLACE_DIRECTION   = new ConfigHotkey("替换方块方向",     "", KeybindSettings.MODIFIER_INGAME, "该快捷键可通过手持模组工具切换到“替换”模式下控制定向或连续替换功能的方向。");
    public static final ConfigHotkey SCHEMATIC_VERSION_CYCLE_MODIFIER   = new ConfigHotkey("原理图版本修改器",     "",     KeybindSettings.MODIFIER_INGAME, "在版本控制工具模式下，需要按住按键才能通过鼠标滚轮查看原理图的版本。");
    public static final ConfigHotkey SCHEMATIC_VERSION_CYCLE_NEXT       = new ConfigHotkey("切换原理图版本到下一个",         "",     "在版本控制工具模式下切换到下一个原理图版本的快捷键。");
    public static final ConfigHotkey SCHEMATIC_VERSION_CYCLE_PREVIOUS   = new ConfigHotkey("切换原理图版本到上一个",     "",     "在版本控制工具模式下切换到下一个原理图版本的快捷键。");
    public static final ConfigHotkey SELECTION_GRAB_MODIFIER            = new ConfigHotkey("选择抓取",             "",     KeybindSettings.MODIFIER_INGAME, "按住该快捷键的同时选择一个选区即可移动改选区。");
    public static final ConfigHotkey SELECTION_GROW_HOTKEY              = new ConfigHotkey("选择扩大",                     "",     "对着任何相邻/对角线连接的方块按下该快捷键可自动扩大区域选择框。");
    public static final ConfigHotkey SELECTION_GROW_MODIFIER            = new ConfigHotkey("选择扩大或者缩小模式",             "",     KeybindSettings.MODIFIER_INGAME, "在按下鼠标滚轮时再按下该快捷键可扩大或缩小区域选择框。");
    public static final ConfigHotkey SELECTION_NUDGE_MODIFIER           = new ConfigHotkey("选区位置修改器",            "LEFT_ALT", KeybindSettings.MODIFIER_INGAME, "按下鼠标滚轮时再按下该快捷键可将指定选区移动到其他区域或者角落。");
    public static final ConfigHotkey SELECTION_MODE_CYCLE               = new ConfigHotkey("选择模式",                "LEFT_CONTROL,M", "在“区域选择”的模式下，在角落和立方体之间修改模式。");
    public static final ConfigHotkey SELECTION_SHRINK_HOTKEY            = new ConfigHotkey("缩小选区",                   "",     "缩小选区的快捷键，使选区的任意一面都没有空隙。");
    public static final ConfigHotkey SET_AREA_ORIGIN                    = new ConfigHotkey("设置选区原点",                     "",     "将当前选区的原点设置或者移动到玩家所在位置。");
    public static final ConfigHotkey SET_SELECTION_BOX_POSITION_1       = new ConfigHotkey("设置选区A点",          "",     "将当前选区的第一个位置坐标点设置成玩家所在位置。");
    public static final ConfigHotkey SET_SELECTION_BOX_POSITION_2       = new ConfigHotkey("设置选区B点",          "",     "将当前选区的第二个位置坐标点设置成玩家所在位置。");
    public static final ConfigHotkey TOGGLE_ALL_RENDERING               = new ConfigHotkey("所有渲染",                "M,R",  "开启或者关闭所有渲染。", "所有渲染");
    public static final ConfigHotkey TOGGLE_AREA_SELECTION_RENDERING    = new ConfigHotkey("区域选择框的渲染", "",     "开启或者关闭区域选择框的渲染。");
    public static final ConfigHotkey TOGGLE_SCHEMATIC_RENDERING         = new ConfigHotkey("原理图渲染",          "M,G",  "开启或者关闭原理图内方块和叠加方块的渲染");
    public static final ConfigHotkey TOGGLE_INFO_OVERLAY_RENDERING      = new ConfigHotkey("方块信息渲染",        "",     "开启或者关闭在预览原理图方块时的信息渲染");
    public static final ConfigHotkey TOGGLE_OVERLAY_RENDERING           = new ConfigHotkey("方块叠加渲染",            "",     "开启或者关闭方块叠加时的渲染。");
    public static final ConfigHotkey TOGGLE_OVERLAY_OUTLINE_RENDERING   = new ConfigHotkey("方块叠加时的轮廓渲染",     "",     "开启或者关闭方块在叠加时的轮廓渲染。");
    public static final ConfigHotkey TOGGLE_OVERLAY_SIDE_RENDERING      = new ConfigHotkey("方块侧面渲染",        "",     "开启或者关闭方块侧面的渲染。");
    public static final ConfigHotkey TOGGLE_PLACEMENT_BOXES_RENDERING   = new ConfigHotkey("放置框的渲染",     "",     "开启或者关闭原理图放置时的边框渲染。");
    public static final ConfigHotkey TOGGLE_PLACEMENT_RESTRICTION       = new ConfigHotkey("切换放置限制",        "",     "用于快速切换放置时限制模式");
    public static final ConfigHotkey TOGGLE_SCHEMATIC_BLOCK_RENDERING   = new ConfigHotkey("原理图方块渲染",     "",     "开启或者关闭原理图方块的渲染。");
    public static final ConfigHotkey TOGGLE_SIGN_TEXT_PASTE             = new ConfigHotkey("告示牌文本粘贴",               "",     "切换告示牌文本粘贴的快捷键（在‘通用’ -> ‘粘贴告示牌文本’中）。");
    public static final ConfigHotkey TOGGLE_TRANSLUCENT_RENDERING       = new ConfigHotkey("幽灵方块的透明渲染",        "",     "用于将幽灵方块切换成半透明或者不透明。");
    public static final ConfigHotkey TOGGLE_VERIFIER_OVERLAY_RENDERING  = new ConfigHotkey("切换原理图验证的叠加渲染",    "",     "切换原理图验证程序的叠加渲染。");
    public static final ConfigHotkey TOOL_ENABLED_TOGGLE                = new ConfigHotkey("模组工具",                 "M,T",  "开启或者关闭模组工具的绑定按键。");//apple
    public static final ConfigHotkey TOOL_PLACE_CORNER_1                = new ConfigHotkey("原理图放置A角",                  "BUTTON_1", KeybindSettings.PRESS_ALLOWEXTRA, "手持模组工具时才能使用的选项，\n可选择成为放置原理图时的第一个角。");
    public static final ConfigHotkey TOOL_PLACE_CORNER_2                = new ConfigHotkey("原理图放置B角",                  "BUTTON_2", KeybindSettings.PRESS_ALLOWEXTRA, "手持模组工具时才能使用的选项，\n可选择成为放置原理图时的第二个角。");
    public static final ConfigHotkey TOOL_SELECT_ELEMENTS               = new ConfigHotkey("切换工具模式",                "BUTTON_3", KeybindSettings.PRESS_ALLOWEXTRA, "手持模组工具时才能使用的选项，\n可用于切换工具的角或者四边形。");
    public static final ConfigHotkey TOOL_SELECT_MODIFIER_BLOCK_1       = new ConfigHotkey("工具方块种类修改器1",          "LEFT_ALT", KeybindSettings.MODIFIER_INGAME, "在使用‘切换工具模式’快捷键时需要按住的快捷键，\n能选择模组工具使用的方块类型。");
    public static final ConfigHotkey TOOL_SELECT_MODIFIER_BLOCK_2       = new ConfigHotkey("工具方块种类修改器2",          "LEFT_SHIFT", KeybindSettings.MODIFIER_INGAME, "在使用‘切换工具模式’快捷键时需要按住的快捷键，\n能选择模组工具使用的辅助方块类型。");
    public static final ConfigHotkey UNLOAD_CURRENT_SCHEMATIC           = new ConfigHotkey("删除当前原理图",            "",     "删除当前放置的原理图，\n因此也会删除由它放置的所有原理图。");
//已将模组汉化版本从1.18 -> 1.19 ，完成时间：2022/11/12 17:20
    public static final List<ConfigHotkey> HOTKEY_LIST = ImmutableList.of(
            ADD_SELECTION_BOX,
            CLONE_SELECTION,
            DELETE_SELECTION_BOX,
            EASY_PLACE_ACTIVATION,
            EASY_PLACE_TOGGLE,
            EXECUTE_OPERATION,
            INVERT_GHOST_BLOCK_RENDER_STATE,
            INVERT_OVERLAY_RENDER_STATE,
            LAYER_MODE_NEXT,
            LAYER_MODE_PREVIOUS,
            LAYER_NEXT,
            LAYER_PREVIOUS,
            LAYER_SET_HERE,
            NUDGE_SELECTION_NEGATIVE,
            NUDGE_SELECTION_POSITIVE,
            MOVE_ENTIRE_SELECTION,
            OPEN_GUI_AREA_SETTINGS,
            OPEN_GUI_LOADED_SCHEMATICS,
            OPEN_GUI_MAIN_MENU,
            OPEN_GUI_MATERIAL_LIST,
            OPEN_GUI_PLACEMENT_SETTINGS,
            OPEN_GUI_SCHEMATIC_PLACEMENTS,
            OPEN_GUI_SCHEMATIC_PROJECTS,
            OPEN_GUI_SCHEMATIC_VERIFIER,
            OPEN_GUI_SELECTION_MANAGER,
            OPEN_GUI_SETTINGS,
            OPERATION_MODE_CHANGE_MODIFIER,
            PICK_BLOCK_FIRST,
            PICK_BLOCK_LAST,
            PICK_BLOCK_TOGGLE,
            RENDER_INFO_OVERLAY,
            RENDER_OVERLAY_THROUGH_BLOCKS,
            RERENDER_SCHEMATIC,
            SAVE_AREA_AS_IN_MEMORY_SCHEMATIC,
            SAVE_AREA_AS_SCHEMATIC_TO_FILE,
            SCHEMATIC_EDIT_BREAK_ALL,
            SCHEMATIC_EDIT_BREAK_ALL_EXCEPT,
            SCHEMATIC_EDIT_BREAK_DIRECTION,
            SCHEMATIC_EDIT_REPLACE_ALL,
            SCHEMATIC_EDIT_REPLACE_BLOCK,
            SCHEMATIC_EDIT_REPLACE_DIRECTION,
            SCHEMATIC_VERSION_CYCLE_MODIFIER,
            SCHEMATIC_VERSION_CYCLE_NEXT,
            SCHEMATIC_VERSION_CYCLE_PREVIOUS,
            SELECTION_GRAB_MODIFIER,
            SELECTION_GROW_HOTKEY,
            SELECTION_GROW_MODIFIER,
            SELECTION_NUDGE_MODIFIER,
            SELECTION_MODE_CYCLE,
            SELECTION_SHRINK_HOTKEY,
            SET_AREA_ORIGIN,
            SET_SELECTION_BOX_POSITION_1,
            SET_SELECTION_BOX_POSITION_2,
            TOGGLE_ALL_RENDERING,
            TOGGLE_AREA_SELECTION_RENDERING,
            TOGGLE_INFO_OVERLAY_RENDERING,
            TOGGLE_OVERLAY_RENDERING,
            TOGGLE_OVERLAY_OUTLINE_RENDERING,
            TOGGLE_OVERLAY_SIDE_RENDERING,
            TOGGLE_PLACEMENT_BOXES_RENDERING,
            TOGGLE_PLACEMENT_RESTRICTION,
            TOGGLE_SCHEMATIC_BLOCK_RENDERING,
            TOGGLE_SCHEMATIC_RENDERING,
            TOGGLE_SIGN_TEXT_PASTE,
            TOGGLE_TRANSLUCENT_RENDERING,
            TOGGLE_VERIFIER_OVERLAY_RENDERING,
            TOOL_ENABLED_TOGGLE,
            TOOL_PLACE_CORNER_1,
            TOOL_PLACE_CORNER_2,
            TOOL_SELECT_ELEMENTS,
            TOOL_SELECT_MODIFIER_BLOCK_1,
            TOOL_SELECT_MODIFIER_BLOCK_2,
            UNLOAD_CURRENT_SCHEMATIC
    );
}
