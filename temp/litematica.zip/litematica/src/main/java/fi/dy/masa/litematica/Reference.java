package fi.dy.masa.litematica;

import fi.dy.masa.malilib.util.StringUtils;

public class Reference
{
    public static final String MOD_ID = "litematica";
    public static final String MOD_NAME = "Litematica";
    public static final String MOD_VERSION = StringUtils.getModVersionString(MOD_ID);
}
