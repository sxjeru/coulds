package fi.dy.masa.litematica.config;

import java.io.File;
import com.google.common.collect.ImmutableList;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import fi.dy.masa.litematica.Reference;
import fi.dy.masa.litematica.data.DataManager;
import fi.dy.masa.litematica.selection.CornerSelectionMode;
import fi.dy.masa.litematica.util.BlockInfoAlignment;
import fi.dy.masa.litematica.util.InventoryUtils;
import fi.dy.masa.litematica.util.PasteNbtBehavior;
import fi.dy.masa.litematica.util.ReplaceBehavior;
import fi.dy.masa.malilib.config.ConfigUtils;
import fi.dy.masa.malilib.config.HudAlignment;
import fi.dy.masa.malilib.config.IConfigBase;
import fi.dy.masa.malilib.config.IConfigHandler;
import fi.dy.masa.malilib.config.options.ConfigBoolean;
import fi.dy.masa.malilib.config.options.ConfigColor;
import fi.dy.masa.malilib.config.options.ConfigDouble;
import fi.dy.masa.malilib.config.options.ConfigInteger;
import fi.dy.masa.malilib.config.options.ConfigOptionList;
import fi.dy.masa.malilib.config.options.ConfigString;
import fi.dy.masa.malilib.util.FileUtils;
import fi.dy.masa.malilib.util.JsonUtils;

public class Configs implements IConfigHandler
{
    private static final String CONFIG_FILE_NAME = Reference.MOD_ID + ".json";

    public static class Generic
    {
        public static final ConfigBoolean       AREAS_PER_WORLD         = new ConfigBoolean(    "世界选区", true, "从每个世界或者服务器的根目录中进行区域选择。\n§6注意：当你在直播时不要关闭该功能，\n§6因为这样做可以让选区目录在指南目录中显示服务器IP，\n§6也能在当前选择名称/路径中显示，\n§6直到你改变在目录中的位置。");
        public static final ConfigBoolean       BETTER_RENDER_ORDER     = new ConfigBoolean(    "更好的渲染顺序", true, "如果设置为true，\n那么原理图的渲染是通过将不同的渲染元素注入原版的渲染代码中完成。\n这会对的半透明方块带来更好的渲染与顺序，\n并且原理图的方块不会通过本地客户端的方块/地形进行渲染。\n如果安装了高清修复（Optifine）之类的模组，\n那么有可能导致渲染无法运行，\n遇到此问题时请删除高清修复之类模组。");
        public static final ConfigBoolean       CHANGE_SELECTED_CORNER  = new ConfigBoolean(    "移动时重置角度", true, "如果设置为true，\n那么在按下设置角度的快捷键时，\n选区内的角总是能恢复成最后移动时的角度。");
        public static final ConfigBoolean       DEBUG_LOGGING           = new ConfigBoolean(    "调试日志", false, "在游戏后台启用一些有关调试日志的信息，\n用于调试某些问题或者崩溃。");
        public static final ConfigBoolean       EASY_PLACE_FIRST        = new ConfigBoolean(    "最近放置", true, "这将会让‘简单放置’功能首先放置你看到/最近的一个方块，\n而不是最远/最底层的方块。\n如果设置为false将允许你多层放置，\n因为最远的方块会被最近放置的方块阻挡视线之前被放置出来。");
        public static final ConfigBoolean       EASY_PLACE_HOLD_ENABLED = new ConfigBoolean(    "启用‘简单放置’", true, "如果设置为true，\n你就能随意地通过快捷键来查看不同的原理图方块来放置它们，\n而不需要单独点击每个方块。");
        public static final ConfigBoolean       EASY_PLACE_MODE         = new ConfigBoolean(    "简单放置", false, "如果设置为true，\n那么只需要在原理图的方块上使用一个物品/放置一个方块，\n就能在该位置上放置原理图的方块。");
        public static final ConfigBoolean       EASY_PLACE_SP_HANDLING  = new ConfigBoolean(    "简单放置-单人游戏", true, "如果设置为true，\n本模组将会在单人游戏中进行‘地毯端精准放置方块’功能。\n如果你安装了“Tweakeroo”模组，那么该模组内的‘clientPlacementRotation’选项也能做到与本功能同样的事。");
        public static final ConfigBoolean       EASY_PLACE_PROTOCOL_V3  = new ConfigBoolean(    "简单放置-V3", true, "如果设置为true，\n那么投影将会使用简单放置模式中的V3版本，\n目前在单人游戏中只有投影本身支持该版本。");
        public static final ConfigBoolean       EXECUTE_REQUIRE_TOOL    = new ConfigBoolean(    "执行操作需手持工具", true, "需要手持已启用的本模组工具物品，\n然后才能让‘执行操作’快捷键生效。");
        public static final ConfigBoolean       FIX_RAIL_ROTATION       = new ConfigBoolean(    "固定方向旋转", true, "如果设置为true，\n那么就会对原版旋转轨道错误进行修复，\n即南北方向与东西方向在180度旋转时会逆时针旋转90度。 >_>");
        public static final ConfigBoolean       GENERATE_LOWERCASE_NAMES = new ConfigBoolean(   "生成小写名称", false, "如果设置为true，\n那么在默认情况下，\n生成的原理图名称将会是小写，\n使用下划线而不是空格来区分。");
        public static final ConfigBoolean       HIGHLIGHT_BLOCK_IN_INV  = new ConfigBoolean(    "高亮原理图方块/物品", false, "如果设置为true，\n将会在背包里高亮原理图材料清单中的方块/物品，\n包括潜影盒内的方块/物品。");
        public static final ConfigBoolean       LAYER_MODE_DYNAMIC      = new ConfigBoolean(    "渲染层跟随玩家", false, "如果设置为true，\n那么渲染层将会跟随玩家。\n注意：目前仅对之前的所有层生效。");
        public static final ConfigBoolean       LOAD_ENTIRE_SCHEMATICS  = new ConfigBoolean(    "加载整个原理图", false, "如果设置为true，\n那么将会一次性加载整个原理图；\n如果是false，\n则每次只加载客户端视距内的那部分原理图。");
        public static final ConfigInteger       PASTE_COMMAND_INTERVAL  = new ConfigInteger(    "粘贴命令间隔", 1, 1, 1000, "在基于粘贴的模式下，\n每次执行粘贴指令之间所需要的间隔，\n单位是tick。");
        public static final ConfigInteger       PASTE_COMMAND_LIMIT     = new ConfigInteger(    "粘贴命令限制", 64, 1, 1000000, "在服务器上使用“将原理图粘贴到世界上”功能时，\n每Tick发送命令的上限。");
        public static final ConfigString        PASTE_COMMAND_SETBLOCK  = new ConfigString(     "粘贴命令设置方块名称", "setblock", "在服务器上使用粘贴模式时，\n粘贴原理图使用的指令“setblock”名称。");
        public static final ConfigBoolean       PASTE_IGNORE_ENTITIES   = new ConfigBoolean(    "粘贴时忽略实体", false, "如果设置为true，\n那么粘贴原理图时将不会粘贴任何实体。");
        public static final ConfigBoolean       PASTE_IGNORE_INVENTORY  = new ConfigBoolean(    "粘贴时忽略容器内容", false, "如果设置为true，\n那么粘贴原理图时将不会粘贴箱子等存储容器中的内容。");
        public static final ConfigOptionList    PASTE_NBT_BEHAVIOR      = new ConfigOptionList( "粘贴NBT数据恢复", PasteNbtBehavior.NONE, "是否尝试还原方块的NBT数据，以及恢复的方式是什么。\n\n- 修改放置与数据：尝试将方块被破坏时的NBT数据保存在玩家附近，\n然后通过数据修改命令将带有NBT数据的方块放置到预定位置。\n\n- 放置与克隆：尝试将带有NBT数据数据的方块放置在玩家附近，\n然后将其克隆到最终位置。\n\n- 放置与传送：尝试将玩家传送至附近，\n然后将带有NBT数据的方块放置在准确位置。\n\n推荐使用“修改放置与数据”，但是为了让它发挥最大作用你可能还需要将‘每Tick指令限制’降低到1格，\n并将‘指令任务间隔’增加到1-4格，\n也可以设置为其他任意数字。\n因此，你应该只在粘贴重要带有NBT数据方块时才使用这个方法。\n例如：制作一个只有一个箱子并存储了物品的原理图，\n然后在替换设置那设置为无。");
        public static final ConfigOptionList    PASTE_REPLACE_BEHAVIOR  = new ConfigOptionList( "粘贴替换操作", ReplaceBehavior.NONE, "在粘贴原理图的工具模式中替换掉现有方块的操作。");
        public static final ConfigBoolean       PASTE_TO_MCFUNCTION     = new ConfigBoolean(    "粘贴到MC文本中", false, "如果设置为true，\n那么不会再将原理图粘贴到世界中，\n而是使用‘/setblock’命令写入文本文件中。");
        public static final ConfigBoolean       PICK_BLOCK_ENABLED      = new ConfigBoolean(    "选取方块", true, "如果设置为true，\n那么将会启用原理图预览中选取方块的快捷键，\n还有一个快捷键是用于切换该选项的... o.o", "选区快捷键");
        public static final ConfigBoolean       PICK_BLOCK_SHULKERS     = new ConfigBoolean(    "快捷切换潜影盒", false, "如果设置为true，\n那么如果在玩家的背包中没有找到原理图材料清单中的物品，\n但是在潜影盒中有，\n那么潜影盒将会被切换到玩家的快捷栏中。");
        public static final ConfigString        PICK_BLOCKABLE_SLOTS    = new ConfigString(     "选取方块快捷键", "1,2,3,4,5", "允许用于原理图选取方块的快捷键。");
        public static final ConfigBoolean       PLACEMENT_RESTRICTION   = new ConfigBoolean(    "放置限制", false, "如果设置为true，\n那么只有在手持对应位置上的物品时才能使用快捷键，\n并且目标位置在原理图中必须要有个缺失的方块。", "放置限制");
        public static final ConfigBoolean       RENDER_MATERIALS_IN_GUI = new ConfigBoolean(    "渲染材料清单GUI", true, "材料清单是否应该显示在GUI内。");
        public static final ConfigBoolean       RENDER_THREAD_NO_TIMEOUT = new ConfigBoolean(   "渲染线程延迟", true, "如果你在移动或者显示大型原理图时渲染并不是很稳定的话，\n可以尝试禁用该功能。\n只不过，在某些特定情况下，\n它将会使原理图的渲染变慢很多。");
        public static final ConfigOptionList    SELECTION_CORNERS_MODE  = new ConfigOptionList( "选择区域模式", CornerSelectionMode.CORNERS, "选择需要使用区域选择的模式（角点或展开）");
        public static final ConfigString        TOOL_ITEM               = new ConfigString(     "工具物品", "minecraft:stick", "选择作为本模组工具的物品。");
        public static final ConfigBoolean       TOOL_ITEM_ENABLED       = new ConfigBoolean(    "启用工具物品", true, "如果设置为true，\n那么‘工具物品’选项可用来执行选择区域等操作", "Tool Item Enabled");
//已将模组汉化版本从1.18 -> 1.16 ，完成时间：2022/11/11 20:40
        public static final ImmutableList<IConfigBase> OPTIONS = ImmutableList.of(
                AREAS_PER_WORLD,
                //BETTER_RENDER_ORDER,
                CHANGE_SELECTED_CORNER,
                DEBUG_LOGGING,
                EASY_PLACE_FIRST,
                EASY_PLACE_HOLD_ENABLED,
                EASY_PLACE_MODE,
                EASY_PLACE_SP_HANDLING,
                EASY_PLACE_PROTOCOL_V3,
                EXECUTE_REQUIRE_TOOL,
                FIX_RAIL_ROTATION,
                GENERATE_LOWERCASE_NAMES,
                HIGHLIGHT_BLOCK_IN_INV,
                LAYER_MODE_DYNAMIC,
                LOAD_ENTIRE_SCHEMATICS,
                PASTE_IGNORE_ENTITIES,
                PASTE_IGNORE_INVENTORY,
                PASTE_NBT_BEHAVIOR,
                PASTE_TO_MCFUNCTION,
                PICK_BLOCK_ENABLED,
                PICK_BLOCK_SHULKERS,
                PLACEMENT_RESTRICTION,
                RENDER_MATERIALS_IN_GUI,
                RENDER_THREAD_NO_TIMEOUT,
                TOOL_ITEM_ENABLED,

                PASTE_REPLACE_BEHAVIOR,
                SELECTION_CORNERS_MODE,

                PASTE_COMMAND_INTERVAL,
                PASTE_COMMAND_LIMIT,
                PASTE_COMMAND_SETBLOCK,
                PICK_BLOCKABLE_SLOTS,
                TOOL_ITEM
        );
    }

    public static class Visuals
    {
        public static final ConfigBoolean       ENABLE_AREA_SELECTION_RENDERING     = new ConfigBoolean("‘区域选择框’渲染", true, "如果设置为true，\n将启用区域选择框的渲染。", "区域选择框的渲染");
        public static final ConfigBoolean       ENABLE_PLACEMENT_BOXES_RENDERING    = new ConfigBoolean("‘投影预览边框’渲染", true, "如果设置为true，\n将启用投影预览边框的渲染。", "投影预览边框渲染");
        public static final ConfigBoolean       ENABLE_RENDERING                    = new ConfigBoolean("所有渲染", true, "启用或禁用所有类型的渲染。", "所有渲染");
        public static final ConfigBoolean       ENABLE_SCHEMATIC_BLOCKS             = new ConfigBoolean("原理图方块渲染",  true, "如果设置为true，\n将渲染原理图内的方块。\n如果设置为false，\n将只能看到方块的颜色。", "原理图方块渲染");
        public static final ConfigBoolean       ENABLE_SCHEMATIC_OVERLAY            = new ConfigBoolean("原理图叠加渲染",  true, "如果设置为true，\n将启用原理图方块的叠加渲染。", "原理图叠加渲染");
        public static final ConfigBoolean       ENABLE_SCHEMATIC_RENDERING          = new ConfigBoolean("原理图渲染", true, "如果设置为true，\n将启用原理图与叠加图等等渲染。", "原理图渲染");
        public static final ConfigDouble        GHOST_BLOCK_ALPHA                   = new ConfigDouble( "幽灵方块的透明度", 0.5, 0, 1, "当渲染为半透明时，\n幽灵方块的透明度。\n§6注意：§7你还需要单独在‘渲染半透明方块’功能处单独开启半透明方块的渲染。");
        public static final ConfigBoolean       IGNORE_EXISTING_FLUIDS              = new ConfigBoolean("忽略现有液体", false, "如果设置为true，\n那么任何流体都会被视作“额外方块”和“错误方块”而不会被计算在原理图中，\n即空气方块和其他类型的方块。\n§6注意：§7你可能还需要同时将‘原理图方块的碰撞箱’功能一起开启才能让含水方块得到正常的渲染。");
        public static final ConfigBoolean       OVERLAY_REDUCED_INNER_SIDES         = new ConfigBoolean("减少内侧渲染", false, "如果设置为true，\n那么不与空气方块直接接触的侧面/内侧将不会被渲染。\n（例如：台阶内侧）");
        public static final ConfigDouble        PLACEMENT_BOX_SIDE_ALPHA            = new ConfigDouble( "子区域边框透明度", 0.2, 0, 1, "子区域边框的透明度。");
        public static final ConfigBoolean       RENDER_AREA_SELECTION_BOX_SIDES     = new ConfigBoolean("侧面区域选择框", true, "如果设置为true，\n那么区域选择框将会以侧面的四边形来显示渲染。");
        public static final ConfigBoolean       RENDER_BLOCKS_AS_TRANSLUCENT        = new ConfigBoolean("渲染半透明方块", false, "如果设置为true，\n将会使用半透明的幽灵方块来渲染原理图。", "渲染半透明方块");
        public static final ConfigBoolean       RENDER_COLLIDING_SCHEMATIC_BLOCKS   = new ConfigBoolean("原理图方块的碰撞箱", false, "如果设置为true，\n那么即使在客户端渲染的世界上存在错误的原理图方块，\n也会正常渲染该方块，\n在建造含雪和含水方块时或许会很有用。");
        public static final ConfigBoolean       RENDER_ERROR_MARKER_CONNECTIONS     = new ConfigBoolean("错误渲染连接线", false, "渲染验证程序与框角之间的连接线，\n有一些人会遇到渲染错误\n，但也有一部分玩家喜欢它，\n所以就保留了它。");
        public static final ConfigBoolean       RENDER_ERROR_MARKER_SIDES           = new ConfigBoolean("错误标记侧面渲染", true, "如果设置为true，\n那么原理图验证程序中的错误标记将以半透明的形式在侧面渲染，\n而不是仅仅是简简单单地轮廓。");
        public static final ConfigBoolean       RENDER_PLACEMENT_BOX_SIDES          = new ConfigBoolean("渲染子区域放置位侧面边框", false, "如果设置为true，\n那么放置原理图子区域的边框将会以侧面四边形的方式来渲染。");
        public static final ConfigBoolean       RENDER_PLACEMENT_ENCLOSING_BOX      = new ConfigBoolean("渲染子区域封闭盒子", true, "如果设置为true，\n那么在原理图中的所有子区域周围将会渲染一个四边形。");
        public static final ConfigBoolean       RENDER_PLACEMENT_ENCLOSING_BOX_SIDES= new ConfigBoolean("渲染原理图侧面四边形", false, "如果设置为true，\n那么会将包围原理图的侧面渲染四边形。");
        public static final ConfigBoolean       RENDER_TRANSLUCENT_INNER_SIDES      = new ConfigBoolean("渲染半透明方块的内侧面", false, "如果设置为true，\n那么在半透明的模式下，\n原理图的侧面也会被渲染成内侧面。");
        public static final ConfigBoolean       SCHEMATIC_OVERLAY_ENABLE_OUTLINES   = new ConfigBoolean("渲染方块轮廓",  true, "如果设置为true，\n那么原理图在叠加时将会渲染方块的轮廓。", "原理图叠加轮廓");
        public static final ConfigBoolean       SCHEMATIC_OVERLAY_ENABLE_SIDES      = new ConfigBoolean("渲染原理图叠加时的侧面",     true, "如果设置为true，\n那么原理图在叠加时的方块将会以半透明的形式对侧面进行渲染。", "原理图侧面");
        public static final ConfigBoolean       SCHEMATIC_OVERLAY_MODEL_OUTLINE     = new ConfigBoolean("渲染原理图叠加模型轮廓",    true, "如果设置为true，\n那么原理图的侧面将会渲染方块模型的四边形/顶点，\n而不是渲染传统的整个方块模型。");
        public static final ConfigBoolean       SCHEMATIC_OVERLAY_MODEL_SIDES       = new ConfigBoolean("渲染原理图叠加模型侧面",      true, "如果设置为true，\n那么原理图的侧面将会渲染方块模型的四边形/顶点，\n而不是渲染传统的整个方块模型。");
        public static final ConfigDouble        SCHEMATIC_OVERLAY_OUTLINE_WIDTH     = new ConfigDouble( "原理图叠加时的轮廓宽度",  1.0, 0, 64, "方块模型的横向宽度。");
        public static final ConfigDouble        SCHEMATIC_OVERLAY_OUTLINE_WIDTH_THROUGH = new ConfigDouble( "原理图叠加通过时的轮廓宽度",  3.0, 0, 64, "当叠加物穿过方块时的，\n方块模型的横向宽度。");
        public static final ConfigBoolean       SCHEMATIC_OVERLAY_RENDER_THROUGH    = new ConfigBoolean("原理图叠加时透视方块", false, "如果设置为true，\n那么原理图在叠加时将不会透视方块，该选项可能只在你建造完成后想要纠错细节的时候才有用。");
        public static final ConfigBoolean       SCHEMATIC_OVERLAY_TYPE_EXTRA        = new ConfigBoolean("额外方块的原理图信息",       true, "是否启用额外方块的原理图信息。");
        public static final ConfigBoolean       SCHEMATIC_OVERLAY_TYPE_MISSING      = new ConfigBoolean("缺失方块的原理图信息",     true, "是否启用缺失方块的原理图信息。");
        public static final ConfigBoolean       SCHEMATIC_OVERLAY_TYPE_WRONG_BLOCK  = new ConfigBoolean("错误方块的原理图信息",  true, "是否启用错误方块的原理图信息");
        public static final ConfigBoolean       SCHEMATIC_OVERLAY_TYPE_WRONG_STATE  = new ConfigBoolean("错误状态下的原理图信息",  true, "是否启用错误状态下的原理图信息。");
        public static final ConfigBoolean       SCHEMATIC_VERIFIER_BLOCK_MODELS     = new ConfigBoolean("原理图验证器使用方块模型", false, "如果设置成true，\n那么将强制对原理图验证程序中的材料清单使用方块模型。\n通常情况下，物品模型仅适用于存有物品的方块，\n除此之外花盆也可被作为包含物品的方块。");
//已将模组汉化版本从1.18 -> 1.16 ，完成时间：2022/11/11 20:50
        public static final ImmutableList<IConfigBase> OPTIONS = ImmutableList.of(
                ENABLE_RENDERING,
                ENABLE_SCHEMATIC_RENDERING,

                ENABLE_AREA_SELECTION_RENDERING,
                ENABLE_PLACEMENT_BOXES_RENDERING,
                ENABLE_SCHEMATIC_BLOCKS,
                ENABLE_SCHEMATIC_OVERLAY,
                IGNORE_EXISTING_FLUIDS,
                OVERLAY_REDUCED_INNER_SIDES,
                RENDER_AREA_SELECTION_BOX_SIDES,
                RENDER_BLOCKS_AS_TRANSLUCENT,
                RENDER_COLLIDING_SCHEMATIC_BLOCKS,
                RENDER_ERROR_MARKER_CONNECTIONS,
                RENDER_ERROR_MARKER_SIDES,
                RENDER_PLACEMENT_BOX_SIDES,
                RENDER_PLACEMENT_ENCLOSING_BOX,
                RENDER_PLACEMENT_ENCLOSING_BOX_SIDES,
                RENDER_TRANSLUCENT_INNER_SIDES,
                SCHEMATIC_OVERLAY_ENABLE_OUTLINES,
                SCHEMATIC_OVERLAY_ENABLE_SIDES,
                SCHEMATIC_OVERLAY_MODEL_OUTLINE,
                SCHEMATIC_OVERLAY_MODEL_SIDES,
                SCHEMATIC_OVERLAY_RENDER_THROUGH,
                SCHEMATIC_OVERLAY_TYPE_EXTRA,
                SCHEMATIC_OVERLAY_TYPE_MISSING,
                SCHEMATIC_OVERLAY_TYPE_WRONG_BLOCK,
                SCHEMATIC_OVERLAY_TYPE_WRONG_STATE,
                SCHEMATIC_VERIFIER_BLOCK_MODELS,

                GHOST_BLOCK_ALPHA,
                PLACEMENT_BOX_SIDE_ALPHA,
                SCHEMATIC_OVERLAY_OUTLINE_WIDTH,
                SCHEMATIC_OVERLAY_OUTLINE_WIDTH_THROUGH
        );
    }

    public static class InfoOverlays
    {
        public static final ConfigOptionList    BLOCK_INFO_LINES_ALIGNMENT          = new ConfigOptionList( "预览方块信息位置", HudAlignment.TOP_RIGHT, "投影信息显示位置，\n默认在右上角。");
        public static final ConfigBoolean       BLOCK_INFO_LINES_ENABLED            = new ConfigBoolean(    "预览方块信息", true, "如果设置为true，\n那么迷你HUD风格的方块信息将会被现已查看的方块覆盖。");
        public static final ConfigDouble        BLOCK_INFO_LINES_FONT_SCALE         = new ConfigDouble(     "预览方块信息字体比例", 0.5, 0, 10, "预览方块信息的字体比例。");
        public static final ConfigInteger       BLOCK_INFO_LINES_OFFSET_X           = new ConfigInteger(    "预览方块信息X轴偏移", 4, 0, 2000, "预览信息与屏幕边缘的X轴的位置偏移量。");
        public static final ConfigInteger       BLOCK_INFO_LINES_OFFSET_Y           = new ConfigInteger(    "预览方块信息Y轴偏移", 4, 0, 2000, "预览信息与屏幕边缘的Y轴的位置偏移量。");
        public static final ConfigOptionList    BLOCK_INFO_OVERLAY_ALIGNMENT        = new ConfigOptionList( "预览信息排列方式", BlockInfoAlignment.TOP_CENTER, "预览方块信息的排列方式。");
        public static final ConfigInteger       BLOCK_INFO_OVERLAY_OFFSET_Y         = new ConfigInteger(    "预览方块叠加信息Y轴偏移", 6, -2000, 2000, "预览方块信息与所选排列方式的Y轴偏移量。");
        public static final ConfigBoolean       BLOCK_INFO_OVERLAY_ENABLED          = new ConfigBoolean(    "方块状态信息效果图", true, "如果设置为true，\n在按下快捷键时将能查看目标方块的信息，\n快捷键名称是：‘方块渲染信息’。", "方块状态信息效果图");
        public static final ConfigOptionList    INFO_HUD_ALIGNMENT                  = new ConfigOptionList( "信息HUD排序方式", HudAlignment.BOTTOM_RIGHT, "信息HUD的排列方式，\n可用于超材料清单，原理图验证程序等位置上。");
        public static final ConfigInteger       INFO_HUD_MAX_LINES                  = new ConfigInteger(    "信息HUD数量上限", 10, 1, 128, "在HUD屏幕上，\n显示信息的最大行数。");
        public static final ConfigInteger       INFO_HUD_OFFSET_X                   = new ConfigInteger(    "信息HUD的X轴偏移", 1, 0, 32000, "信息HUD与屏幕边缘的X轴偏移量。");
        public static final ConfigInteger       INFO_HUD_OFFSET_Y                   = new ConfigInteger(    "信息HUD的Y轴偏移", 1, 0, 32000, "信息HUD与屏幕边缘的Y轴偏移量。");
        public static final ConfigDouble        INFO_HUD_SCALE                      = new ConfigDouble(     "信息HUD字体比例", 1, 0.1, 4, "信息HUD的字体比例。");
        public static final ConfigBoolean       INFO_OVERLAYS_TARGET_FLUIDS         = new ConfigBoolean(    "流体信息", false, "如果设置为true，\n那么预览方块信息和信息HUD的在显示时将会包括流体方块，而不是直接穿过它们。");
        public static final ConfigInteger       MATERIAL_LIST_HUD_MAX_LINES         = new ConfigInteger(    "材料清单行数", 10, 1, 128, "信息HUD显示材料清单中的物品最大行数。");
        public static final ConfigDouble        MATERIAL_LIST_HUD_SCALE             = new ConfigDouble(     "材料清单信息大小", 1, 0.1, 4, "材料清单中的信息HUD的比例。");
        public static final ConfigBoolean       STATUS_INFO_HUD                     = new ConfigBoolean(    "状态信息HUD", false, "如果设置为true，\n那么将会启用信息HUD的渲染程序，\n能渲染一些状态信息，\n例如当前层数与是否启用渲染信息等。");
        public static final ConfigBoolean       STATUS_INFO_HUD_AUTO                = new ConfigBoolean(    "自动显示状态信息", true, "如果设置成true，\n那么将能在不需要使用状态信息HUD信息的时候自动禁用，\n例如：在选择一个区域后停止渲染。");
        public static final ConfigOptionList    TOOL_HUD_ALIGNMENT                  = new ConfigOptionList( "工具HUD信息对齐", HudAlignment.BOTTOM_LEFT, "当手持本模组的工具时，工具HUD信息的对齐状态。");
        public static final ConfigInteger       TOOL_HUD_OFFSET_X                   = new ConfigInteger(    "工具HUD信息的X轴偏移", 1, 0, 32000, "工具信息HUD与屏幕边缘的X轴偏移量。");
        public static final ConfigInteger       TOOL_HUD_OFFSET_Y                   = new ConfigInteger(    "工具HUD信息的Y轴偏移", 1, 0, 32000, "工具信息HUD与屏幕边缘的Y轴偏移量。");
        public static final ConfigDouble        TOOL_HUD_SCALE                      = new ConfigDouble(     "工具HUD信息的字体比例", 1, 0.1, 4, "工具HUD的字体比例。");
        public static final ConfigDouble        VERIFIER_ERROR_HILIGHT_ALPHA        = new ConfigDouble(     "验证程序边框透明度", 0.2, 0, 1, "验证程序边框的透明度。");
        public static final ConfigInteger       VERIFIER_ERROR_HILIGHT_MAX_POSITIONS = new ConfigInteger(   "验证程序显示错误的数量", 1000, 1, 1000000, "在原理图验证程序中一次显示的错误数量。");
        public static final ConfigBoolean       VERIFIER_OVERLAY_ENABLED            = new ConfigBoolean(    "验证程序叠加渲染", true, "如果设置为true，\n则原理图验证程序标记将会叠加渲染。", "验证程序叠加渲染");
        public static final ConfigBoolean       WARN_DISABLED_RENDERING             = new ConfigBoolean(    "渲染禁用警告信息", true, "如果设置为true，\n则在加载新原理图或者新建布局时，会显示有关图层模式或者某些功能被禁用的警告信息。");
//已将模组汉化版本从1.18 -> 1.16 ，完成时间：2022/11/11 20:53
        public static final ImmutableList<IConfigBase> OPTIONS = ImmutableList.of(
                BLOCK_INFO_LINES_ENABLED,
                BLOCK_INFO_OVERLAY_ENABLED,
                INFO_OVERLAYS_TARGET_FLUIDS,
                STATUS_INFO_HUD,
                STATUS_INFO_HUD_AUTO,
                VERIFIER_OVERLAY_ENABLED,
                WARN_DISABLED_RENDERING,

                BLOCK_INFO_LINES_ALIGNMENT,
                BLOCK_INFO_OVERLAY_ALIGNMENT,
                INFO_HUD_ALIGNMENT,
                TOOL_HUD_ALIGNMENT,

                BLOCK_INFO_LINES_OFFSET_X,
                BLOCK_INFO_LINES_OFFSET_Y,
                BLOCK_INFO_LINES_FONT_SCALE,
                BLOCK_INFO_OVERLAY_OFFSET_Y,
                INFO_HUD_MAX_LINES,
                INFO_HUD_OFFSET_X,
                INFO_HUD_OFFSET_Y,
                INFO_HUD_SCALE,
                MATERIAL_LIST_HUD_MAX_LINES,
                MATERIAL_LIST_HUD_SCALE,
                TOOL_HUD_OFFSET_X,
                TOOL_HUD_OFFSET_Y,
                TOOL_HUD_SCALE,
                VERIFIER_ERROR_HILIGHT_ALPHA,
                VERIFIER_ERROR_HILIGHT_MAX_POSITIONS
        );
    }
//igansigaiyga45
    public static class Colors
    {
        public static final ConfigColor AREA_SELECTION_BOX_SIDE_COLOR       = new ConfigColor("区域选择框侧面颜色",          "0x30FFFFFF", "未选中时的区域选择框的颜色。");
        public static final ConfigColor HIGHTLIGHT_BLOCK_IN_INV_COLOR       = new ConfigColor("背包高亮材料清单方块颜色",    "#30FF30FF", "背包拥有材料清单中方块的颜色。");
        public static final ConfigColor MATERIAL_LIST_HUD_ITEM_COUNTS       = new ConfigColor("材料清单中的物品数量颜色",     "0xFFFFAA00", "材料清单中的信息HUD界面里物品数量的颜色。");
        public static final ConfigColor REBUILD_BREAK_OVERLAY_COLOR         = new ConfigColor("编辑模式的叠加颜色", "0x4C33CC33", "原理图编辑模式或放置方块选择框的颜色。");
        public static final ConfigColor REBUILD_BREAK_EXCEPT_OVERLAY_COLOR  = new ConfigColor("除放置模式外的颜色", "0x4CF03030", "原理图编辑模式中除了放置模式外的所有方块的颜色。");
        public static final ConfigColor REBUILD_REPLACE_OVERLAY_COLOR       = new ConfigColor("替换模式颜色",    "0x4CF0A010", "原理图编辑模式的替换模式叠加层颜色。");
        public static final ConfigColor SCHEMATIC_OVERLAY_COLOR_EXTRA       = new ConfigColor("额外方块叠加颜色",         "0x4CFF4CE6", "额外方块叠加的颜色。");
        public static final ConfigColor SCHEMATIC_OVERLAY_COLOR_MISSING     = new ConfigColor("缺少方块叠加颜色",       "0x2C33B3E6", "缺少方块叠加的颜色。");
        public static final ConfigColor SCHEMATIC_OVERLAY_COLOR_WRONG_BLOCK = new ConfigColor("错误方块叠加颜色",    "0x4CFF3333", "错误方块叠加的颜色。");
        public static final ConfigColor SCHEMATIC_OVERLAY_COLOR_WRONG_STATE = new ConfigColor("错误方块状态叠加颜色",    "0x4CFF9010", "错误方块状态叠加的颜色。");
//已将模组汉化版本从1.18 -> 1.16 ，完成时间：2022/11/11 20:55
        public static final ImmutableList<IConfigBase> OPTIONS = ImmutableList.of(
                AREA_SELECTION_BOX_SIDE_COLOR,
                HIGHTLIGHT_BLOCK_IN_INV_COLOR,
                MATERIAL_LIST_HUD_ITEM_COUNTS,
                REBUILD_BREAK_OVERLAY_COLOR,
                REBUILD_BREAK_EXCEPT_OVERLAY_COLOR,
                REBUILD_REPLACE_OVERLAY_COLOR,
                SCHEMATIC_OVERLAY_COLOR_EXTRA,
                SCHEMATIC_OVERLAY_COLOR_MISSING,
                SCHEMATIC_OVERLAY_COLOR_WRONG_BLOCK,
                SCHEMATIC_OVERLAY_COLOR_WRONG_STATE
        );
    }

    public static void loadFromFile()
    {
        File configFile = new File(FileUtils.getConfigDirectory(), CONFIG_FILE_NAME);

        if (configFile.exists() && configFile.isFile() && configFile.canRead())
        {
            JsonElement element = JsonUtils.parseJsonFile(configFile);

            if (element != null && element.isJsonObject())
            {
                JsonObject root = element.getAsJsonObject();

                ConfigUtils.readConfigBase(root, "Colors", Colors.OPTIONS);
                ConfigUtils.readConfigBase(root, "Generic", Generic.OPTIONS);
                ConfigUtils.readConfigBase(root, "Hotkeys", Hotkeys.HOTKEY_LIST);
                ConfigUtils.readConfigBase(root, "InfoOverlays", InfoOverlays.OPTIONS);
                ConfigUtils.readConfigBase(root, "Visuals", Visuals.OPTIONS);
            }
        }

        DataManager.setToolItem(Generic.TOOL_ITEM.getStringValue());
        InventoryUtils.setPickBlockableSlots(Generic.PICK_BLOCKABLE_SLOTS.getStringValue());
    }

    public static void saveToFile()
    {
        File dir = FileUtils.getConfigDirectory();

        if ((dir.exists() && dir.isDirectory()) || dir.mkdirs())
        {
            JsonObject root = new JsonObject();

            ConfigUtils.writeConfigBase(root, "Colors", Colors.OPTIONS);
            ConfigUtils.writeConfigBase(root, "Generic", Generic.OPTIONS);
            ConfigUtils.writeConfigBase(root, "Hotkeys", Hotkeys.HOTKEY_LIST);
            ConfigUtils.writeConfigBase(root, "InfoOverlays", InfoOverlays.OPTIONS);
            ConfigUtils.writeConfigBase(root, "Visuals", Visuals.OPTIONS);

            JsonUtils.writeJsonToFile(root, new File(dir, CONFIG_FILE_NAME));
        }
    }

    @Override
    public void load()
    {
        loadFromFile();
    }

    @Override
    public void save()
    {
        saveToFile();
    }
}
